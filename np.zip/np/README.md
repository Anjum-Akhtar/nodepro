# nodepro
This is a node simple project wirh register, login and logout.

# Main entry file
app.js 
    This file will handle all your routes and logic
    
# Node.js dependencies
package.json  